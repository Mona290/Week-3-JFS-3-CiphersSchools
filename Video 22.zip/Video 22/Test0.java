class worker extends Thread{
    public void run(){
        //run is a predefined method, when a threa is started it
        //automatically looks for run method.
        //the job of a thread is defined inside run method.
       for(int i=1;i<=10;i++){
        System.out.println("Thread 1 Running..."+ new java.util.Date());
       
        try {
            Thread.sleep(1000); //1000 ms=1sec
        } catch (InterruptedException e){
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
}
public class Test0{
    public static void main(String[] args){
        worker w1 = new worker();
        w1.start(); //start method is used to start Thread. which indirectly calls run()method
        
    }
}