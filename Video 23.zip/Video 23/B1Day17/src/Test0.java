import java.sql.Connection;
import java.sql.DriverManager;

public class Test0 {
	
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String connectionURL="jdbc:mysql://localhost/booksdb";
			Connection conn = DriverManager.getConnection(connectionURL,"root","<passwordhere");
			System.out.println("Connected to server Successfully!!!");
			conn.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
